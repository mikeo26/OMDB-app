<?php include 'head.php'; ?>


<div class="container">
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<h1 class="page-title">404 - Pagina niet gevonden</h1>
			<p> Oops! De pagina waar je naar zocht bestaat niet (meer) of is verplaatst.</p>
		</div>
	</div>
</div>

<?php include 'footer.php'; ?>