<?php include 'head.php'; ?>
	
	<div class="container">
		<div class="row">
			
		</div>
				<h1>Films</h1>
				<div id="filmOverzicht" class="row">
					<div class="col-md-12 bs-callout bs-callout-danger">
						<?php  include 'assets/no-javascript.php'; ?>
					</div>
				</div>

	</div>

<?php include 'footer.php'; ?>