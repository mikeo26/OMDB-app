<noscript>
	<div class="alert alert-dismissible alert-danger">
		<p>De browser kan de films niet ophalen omdat Javascript uitstaat in uw browser. Om gebruik te maken van deze website dient u Javascript aan te zetten.</p>
		<p>Klik op de knop hieronder om te lezen hoe U Javascript aan kunt zetten</p><br>
		<a href="http://www.enable-javascript.com/nl/" target="_blank" class="btn btn-primary" style="display: block; margin: 0 auto; width: 350px">Javascript aanzetten</a>
	</div>
</noscript>
